﻿Imports System.Windows.Forms.DataVisualization.Charting
Imports System.IO
Imports System.Drawing.Printing

Module GraphFunctions

    Private CurrentGraph As Chart

    Public Function SaveGraph(ByVal CurrentChart As Chart) As Boolean

        Dim sfdSave As New SaveFileDialog()
        sfdSave.Filter = "Bitmap (*.bmp)|*.bmp|JPEG (*.jpg)|*.jpg|EMF (*.emf)|*.emf|PNG (*.png)|*.png|GIF (*.gif)|*.gif|TIFF (*.tif)|*.tif"
        sfdSave.FilterIndex = 2
        sfdSave.RestoreDirectory = True
        If sfdSave.ShowDialog() = DialogResult.OK Then ' Set image file format
            Dim format As ChartImageFormat = ChartImageFormat.Bmp
            If sfdSave.FileName.EndsWith("jpg") Then
                format = ChartImageFormat.Jpeg
            Else
                If sfdSave.FileName.EndsWith("emf") Then
                    format = ChartImageFormat.Emf
                Else
                    If sfdSave.FileName.EndsWith("gif") Then
                        format = ChartImageFormat.Gif
                    Else
                        If sfdSave.FileName.EndsWith("png") Then
                            format = ChartImageFormat.Png
                        Else
                            If sfdSave.FileName.EndsWith("tif") Then
                                format = ChartImageFormat.Tiff
                            End If
                        End If ' Save image
                    End If
                End If
            End If
            CurrentChart.SaveImage(sfdSave.FileName, format)
            Return True
        Else
            Return False
        End If

    End Function

    Public Sub CopyToClipboard(ByVal CurrentChart As Chart)

        Dim stream As New System.IO.MemoryStream() ' Create a memory stream to save the chart image    
        CurrentChart.SaveImage(stream, System.Drawing.Imaging.ImageFormat.Bmp) ' Save the chart image to the stream    
        Dim bmp As New Bitmap(stream) ' Create a bitmap using the stream    
        Clipboard.SetDataObject(bmp) ' Save the bitmap to the clipboard    

    End Sub

    Public Sub PrintGraph(ByVal CurrentChart As Chart)

        CurrentGraph = CurrentChart
        CurrentGraph.Printing.PrintDocument = New PrintDocument
        AddHandler CurrentGraph.Printing.PrintDocument.PrintPage, AddressOf PrintPage
        CurrentGraph.Printing.Print(True)

    End Sub

    Public Sub PreviewGraph(ByVal CurrentChart As Chart)

        CurrentChart.Printing.PrintPreview()

    End Sub

    Private Sub PrintPage(ByVal sender As Object, ByVal ev As PrintPageEventArgs)

        '' Calculate title string position
        Dim titlePosition As New Rectangle(ev.MarginBounds.X, ev.MarginBounds.Y, ev.MarginBounds.Width, ev.MarginBounds.Height)
        Dim stream As New System.IO.MemoryStream() ' Create a memory stream to save the chart image    
        CurrentGraph.SaveImage(stream, System.Drawing.Imaging.ImageFormat.Bmp) ' Save the chart image to the stream    
        Dim bmp As New Bitmap(stream) ' Create a bitmap using the stream    
        Dim recPic As New Rectangle(ev.MarginBounds.X, ev.MarginBounds.Y, bmp.Width, bmp.Height)
        Dim fontTitle As New Font("Times New Roman", 16)
        Dim chartTitle As String = String.Empty
        If CurrentGraph.Titles.Count > 0 Then
            chartTitle = CurrentGraph.Titles(0).Text
        End If
        'Dim titleSize As SizeF = ev.Graphics.MeasureString(chartTitle, fontTitle)
        ' titlePosition.Height = CInt(titleSize.Height)

        '' Draw charts title
        'Dim format As New StringFormat()
        'format.Alignment = StringAlignment.Center
        'ev.Graphics.DrawString(chartTitle, fontTitle, Brushes.Black, titlePosition, format)

        '' Calculate first chart position rectangle
        Dim chartPosition As New Rectangle(ev.MarginBounds.X, titlePosition.Bottom, CurrentGraph.Size.Width, CurrentGraph.Size.Height)

        '' Align first chart position on the page
        Dim chartWidthScale As Single = 1 ' CSng(ev.MarginBounds.Width) / 2.0F / CSng(chartPosition.Width)
        Dim chartHeightScale As Single = 1 'CSng(ev.MarginBounds.Height) / CSng(chartPosition.Height)
        chartPosition.Width = CInt(chartPosition.Width * Math.Min(chartWidthScale, chartHeightScale))
        chartPosition.Height = CInt(chartPosition.Height * Math.Min(chartWidthScale, chartHeightScale))

        ' Draw first chart on the printer graphics
        'CurrentGraph.Printing.PrintPaint(ev.Graphics, chartPosition)
        ev.Graphics.DrawImage(bmp, recPic)

    End Sub

    Public Function IsHoliday(ByVal BusinessDay As Date) As Boolean

        Dim StartDate As Date = #12/19/2009#
        Dim EndDate As Date = #1/3/2010#
        If BusinessDay >= StartDate And BusinessDay <= EndDate Then
            Return True
        Else
            Return False
        End If

    End Function

End Module

