﻿Imports System.Windows.Forms.DataVisualization.Charting
Imports System.ComponentModel
Imports System.Drawing.Imaging

Class frmChartExample

#Region "Local Variables"

    Private lstCategories As List(Of Category) 'List of Product Categories
    Private lstDataPoints As List(Of AppDataPoint)
    Private CurrentCategory As Category
    Private strErrorLog As String = Application.StartupPath & "\" & My.Settings.ErrorLog
    Private lstGrossSales As List(Of Decimal) ' Collection of decimals for Gross Sales Last 4 months
    Private gsCurrentStage As GraphStage 'Flag to tell which type of Graph is current
    Private gmGraphMonth As GraphMonth

#End Region

#Region "Local Enums"

    Private Enum GraphStage

        Pyramid
        Doughnut

    End Enum

    Private Enum GraphMonth

        Month1
        Month2
        Month3
        Current

    End Enum

#End Region

#Region "Local Routines"

    Private Sub SetGraphMonth() 'Sets enum GraphMonth depending on which RadioButton is checked

        If rbtnMonth1.Checked = True Then
            gmGraphMonth = 0
        ElseIf rbtnMonth2.Checked Then
            gmGraphMonth = 1
        ElseIf rbtnMonth3.Checked Then
            gmGraphMonth = 2
        Else
            gmGraphMonth = 3
        End If

    End Sub

    Private Sub SetUpGraph()

        Dim blnPercent As Boolean = rbtnPercent.Checked 'Select whether values shown as Retail or as Percent
        mscSales.Series(0).Points.Clear() 'Clear Graph
        SetGraphMonth() 'Set enum GraphMonth
        Select Case gsCurrentStage
            Case GraphStage.Doughnut
                SetPercentageChoice(True)
                btnReturn.Visible = True
                dgvDetails.Columns(0).HeaderText = "Product"
                mscSales.Series(0).ChartType = SeriesChartType.Doughnut
                mscSales.Series(0)("CollectedThreshold") = tbGroupPercentage.Value
                mscSales.Titles(0).Text = CurrentCategory.Name.ToUpper & " - SALES BY PRODUCT"
                lstDataPoints = SetUpPiePoints(blnPercent, rbtnUnitSales.Checked)
                lstDataPoints.Sort()
            Case Else
                SetPercentageChoice(False)
                btnReturn.Visible = False
                mscSales.Series(0).ChartType = SeriesChartType.Pyramid
                mscSales.Series(0).IsXValueIndexed = False
                mscSales.Titles(0).Text = "SALES BY CATEGORY - PERCENT OF GROSS SALES"
                lstDataPoints = SetUpPyramidPoints(blnPercent)
        End Select
        dgvDetails.Rows.Clear()
        Dim decGross As Decimal = 0D
        For intDataPoints As Integer = 0 To lstDataPoints.Count - 1
            mscSales.Series(0).Points.AddXY(lstDataPoints(intDataPoints).DataKey, Format(lstDataPoints(intDataPoints).DataValue, "#,##0.00"))
            Dim strRow() As String = {lstDataPoints(intDataPoints).DataKey, Format(lstDataPoints(intDataPoints).DataValue, "#,##0.00")}
            decGross += lstDataPoints(intDataPoints).DataValue
            dgvDetails.Rows.Add(strRow)
        Next
        dgvDetails.Rows.Add()
        Dim strGross() As String = {"Total ", Format(decGross, "#,##0.00")}
        dgvDetails.Rows.Add(strGross)

    End Sub

    Private Sub SetPercentageChoice(ByVal IsVisible As Boolean)

        tbGroupPercentage.Visible = IsVisible
        lbl0.Visible = IsVisible
        lbl20.Visible = IsVisible
        lblPercentageValue.Visible = IsVisible
        pnlGroupPercentage.Visible = IsVisible

    End Sub

    Private Function SetUpPyramidPoints(ByVal IsPercent As Boolean) As List(Of AppDataPoint)

        Dim lstDP As New List(Of AppDataPoint)
        For intCategories As Integer = 0 To lstCategories.Count - 1
            Dim newDP As New AppDataPoint
            If IsPercent Then
                If lstGrossSales(gmGraphMonth) > 0 Then
                    newDP.DataValue = (lstCategories(intCategories).TotalSales(gmGraphMonth) / lstGrossSales(gmGraphMonth)) * 100
                Else
                    newDP.DataValue = 0
                End If
            Else
                newDP.DataValue = lstCategories(intCategories).TotalSales(gmGraphMonth)
            End If
            newDP.DataKey = lstCategories(intCategories).Name
            newDP.Tag = lstCategories(intCategories)
            lstDP.Add(newDP)
        Next
        Return lstDP

    End Function

    Private Function SetUpPiePoints(ByVal IsPercent As Boolean, ByVal IsUnitSales As Boolean) As List(Of AppDataPoint)

        Dim lstDP As New List(Of AppDataPoint)
        For intProducts As Integer = 0 To CurrentCategory.Products.Count - 1
            Dim newDP As New AppDataPoint
            If IsPercent Then
                If CurrentCategory.Products(intProducts).UnitSales(gmGraphMonth) > 0 Then
                    newDP.DataValue = ((CurrentCategory.Products(intProducts).UnitSales(gmGraphMonth) * CurrentCategory.Products(intProducts).RetailPrice) / CurrentCategory.TotalSales(gmGraphMonth)) * 100
                Else
                    newDP.DataValue = 0
                End If
            ElseIf IsUnitSales Then
                newDP.DataValue = CurrentCategory.Products(intProducts).UnitSales(gmGraphMonth)
            Else
                newDP.DataValue = CurrentCategory.Products(intProducts).UnitSales(gmGraphMonth) * CurrentCategory.Products(intProducts).RetailPrice
            End If
            newDP.DataKey = CurrentCategory.Products(intProducts).Name
            newDP.Tag = CurrentCategory.Products(intProducts)
            lstDP.Add(newDP)
        Next
        Return lstDP

    End Function

    'Routine to dynamically assign month names to Radio Buttons
    Private Sub SetupLabels()

        rbtnMonth1.Text = "November, 2009" ' MonthName(Now.AddMonths(-3).Month) & ", " & Now.AddMonths(-3).Year
        rbtnMonth2.Text = "December, 2009" 'MonthName(Now.AddMonths(-2).Month) & ", " & Now.AddMonths(-2).Year
        rbtnMonth3.Text = "January, 2010" 'MonthName(Now.AddMonths(-1).Month) & ", " & Now.AddMonths(-1).Year
        rbtnMonth4.Text = "February, 2010" 'MonthName(Now.Month) & ", " & Now.Year

    End Sub

    Private Sub SetUpCategories()

        lstCategories = Category.GetAllCategories(My.Settings.ConString)
        lstGrossSales = New List(Of Decimal)
        For intMonths As Integer = 0 To 3 'Instantiate lstGrossSales
            lstGrossSales.Add(0)
        Next
        For intCategories As Integer = 0 To lstCategories.Count - 1
            For intmonths = 0 To 3
                lstGrossSales(intmonths) += lstCategories(intCategories).TotalSales(intmonths)
            Next
        Next

    End Sub

#Region "Form Control Events"

    Private Sub chSales_GetToolTipText(ByVal sender As Object, ByVal e As System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs) Handles mscSales.GetToolTipText

        Select Case e.HitTestResult.ChartElementType
            Case ChartElementType.DataPoint
                If e.HitTestResult.PointIndex >= 0 Then
                    Dim strKey As String = lstDataPoints(e.HitTestResult.PointIndex).DataKey
                    Dim strValue As String = Format(lstDataPoints(e.HitTestResult.PointIndex).DataValue, "#,##0.00")
                    e.Text = strKey & ", " & strValue
                End If
        End Select

    End Sub

    Private Sub chSales_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles mscSales.MouseDown

        Dim htrResult As HitTestResult = mscSales.HitTest(e.X, e.Y)
        If htrResult.ChartElementType = ChartElementType.DataPoint And htrResult.PointIndex >= 0 Then
            SetGraphMonth()
            If gsCurrentStage = GraphStage.Pyramid Then
                gsCurrentStage = GraphStage.Doughnut
                CurrentCategory = lstCategories(htrResult.PointIndex)
                tbGroupPercentage.Value = 3
                rbtnUnitSales.Visible = True
                SetUpGraph()
            Else
                Dim newProductGraph As New ProductSales(CType(lstDataPoints(htrResult.PointIndex).Tag, Product))
                newProductGraph.Show()
            End If
        End If

    End Sub

    Private Sub chSales_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles mscSales.MouseMove

        Dim htrResult As HitTestResult = mscSales.HitTest(e.X, e.Y)
        'Go through points setting design elements back to default
        For Each dp As DataPoint In mscSales.Series(0).Points
            dp.BackSecondaryColor = Color.White
            dp.BackHatchStyle = ChartHatchStyle.None
            dp.BorderWidth = 0
        Next dp
        'If users mouse hovers over a datapoint or it's equivalent Legend Item then set cursor to hand to indicate that it is a link
        'Also we use some design elements to indicate which DataPoint is active
        If htrResult.PointIndex >= 0 Then
            If htrResult.ChartElementType = ChartElementType.DataPoint Or htrResult.ChartElementType = ChartElementType.LegendItem Then
                Me.Cursor = Cursors.Hand
                Dim dpSelected As DataPoint
                dpSelected = mscSales.Series(0).Points(htrResult.PointIndex)
                dpSelected.BackSecondaryColor = Color.Black
                dpSelected.BorderColor = Color.White
                dpSelected.BorderWidth = 1
            End If
        Else
            'Set cursor back to default when leaving selected datapoint
            Me.Cursor = Cursors.Default
        End If

    End Sub

    Private Sub frmChartExample_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        SetupLabels()
        SetUpCategories()
        rbtnMonth4.Checked = True
        rbtnPercent.Checked = True
        gsCurrentStage = GraphStage.Pyramid
        SetUpGraph()

    End Sub

    Private Sub btnReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReturn.Click

        gsCurrentStage = GraphStage.Pyramid
        rbtnUnitSales.Visible = False
        SetUpGraph()
        btnReturn.Visible = False
        SetPercentageChoice(False)

    End Sub

    'Private Sub chSales_PostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataVisualization.Charting.ChartPaintEventArgs) Handles chSales.PostPaint

    '    ' Painting series object
    '    If TypeOf sender Is System.Windows.Forms.DataVisualization.Charting.Chart Then
    '        Dim chart As System.Windows.Forms.DataVisualization.Charting.Chart = CType(sender, Chart)
    '        Dim series As Series = chart.Series(0)
    '        ' Find data point with maximum Y value
    '        For Each dp As DataPoint In series.Points
    '            Dim dataPoint As DataPoint = dp

    '            ' Load bitmap from file 
    '            Dim bitmap As System.Drawing.Image = Image.FromFile("D:\Documents\Visual Studio 2008\Projects\Code Project Articles\CodeProjectGraphArticle\CodeProjectGraphArticle\" & dp.AxisLabel.ToString & ".png")

    '            ' Set Red color as transparent
    '            Dim attrib As New ImageAttributes()
    '            attrib.SetColorKey(Color.Red, Color.Red, ColorAdjustType.Default)
    '            ' Calculates marker position depending on the data point X and Y values
    '            Dim imagePosition As RectangleF = RectangleF.Empty
    '            imagePosition.X = CSng(e.ChartGraphics.GetPositionFromAxis("ChartArea1", AxisName.X, dataPoint.XValue))
    '            imagePosition.Y = CSng(e.ChartGraphics.GetPositionFromAxis("ChartArea1", AxisName.Y, dataPoint.YValues(0)))
    '            imagePosition = e.ChartGraphics.GetAbsoluteRectangle(imagePosition)
    '            imagePosition.Width = bitmap.Width
    '            imagePosition.Height = bitmap.Height
    '            'imagePosition.Y -= 10
    '            ' imagePosition.X -= 1
    '            ' Draw image
    '            e.ChartGraphics.Graphics.DrawImage(bitmap, Rectangle.Round(imagePosition), 0, 0, bitmap.Width, bitmap.Height, GraphicsUnit.Pixel, attrib)
    '            ' Dispose image object
    '            bitmap.Dispose()
    '        Next dp
    '    End If


    'End Sub

    Private Sub tbGroupPercentage_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tbGroupPercentage.ValueChanged

        Dim strPercent As String = "Grouping Products having less than " & tbGroupPercentage.Value & " % of Sales"
        lblPercentageValue.Text = strPercent.ToUpper(System.Globalization.CultureInfo.CurrentCulture)
        SetUpGraph()

    End Sub

    Private Sub CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtnGross.CheckedChanged, _
                                                                                                                                             rbtnMonth1.CheckedChanged, _
                                                                                                                                             rbtnMonth2.CheckedChanged, _
                                                                                                                                             rbtnMonth3.CheckedChanged, _
                                                                                                                                             rbtnMonth4.CheckedChanged, _
                                                                                                                                             rbtnPercent.CheckedChanged, _
                                                                                                                                             rbtnUnitSales.CheckedChanged

        If CType(sender, RadioButton).Checked Then
            SetUpGraph()
        End If

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click

        Me.Close()

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        Try
            If SaveGraph(mscSales) Then
                MsgBox("Graph successfully saved.")
            End If
        Catch ex As System.IO.IOException
            MsgBox("There was an error saving the Graph. Please try again. If the problem persists, please call your System Administrator.")
        End Try

    End Sub

    Private Sub btnCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopy.Click

        CopyToClipboard(mscSales)

    End Sub

    Private Sub btnPrintPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click

        PreviewGraph(mscSales)

    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click

        Try
            PrintGraph(mscSales)
        Catch ex As System.Drawing.Printing.InvalidPrinterException
            MsgBox("There was an error printing the Report. Please try again. If the problem persists, please call your System Administrator.")
        End Try

    End Sub

#End Region 'Form Control Events

#End Region 'Local Routines

End Class
