﻿Imports System.Windows.Forms.DataVisualization.Charting

Class ProductSales

#Region "Class Variables"

    Private prdCurrent As Product 'Current product whose results need to be shown. Passed and set through constructor.
    Private lstMonths As List(Of String) 'A list of the past three full calendar months plus current month by name
    Private dteStartDate As Date = #11/1/2009# 'Start Date for Demo App figures
    Private dteEndDate As Date = #2/19/2010# 'End Date for Demo App figures

#End Region

#Region "Class Routines"

#Region "Constructors"

    Public Sub New(ByVal CurrentProduct As Product)

        InitializeComponent()
        prdCurrent = CurrentProduct 'Initialise the current product

    End Sub

#End Region
    'Fetches a DataTable from current product DailySales routine and sets
    'it as the BindingSource for the Graph.
    'Calculates and sets result details on form
    Private Sub SetGraph()

        Dim dtMasterSales As DataTable = prdCurrent.DailySales(dteStartDate, dteEndDate, My.Settings.ConString)
        mscDailySales.DataSource = dtMasterSales
        mscDailySales.Series(0).XValueMember = "Date"
        mscDailySales.Series(0).YValueMembers = "UnitsSold"
        mscDailySales.DataBind()
        Dim dblMean As Double = mscDailySales.DataManipulator.Statistics.Mean("Series1") 'uses datamanipulator to return mean
        lblAveSales.Text = Format(dblMean, "0.00")
        Dim lstDates As New List(Of Date)
        Dim lstValues As New List(Of Double)
        Dim intTotalUnitsSold As Integer = 0
        For i As Integer = 0 To dtMasterSales.Rows.Count - 1
            intTotalUnitsSold += dtMasterSales.Rows(i).Item(1)
            lstDates.Add(dtMasterSales.Rows(i).Item(0))
            lstValues.Add(dblMean)
        Next
        mscDailySales.Series(1).Points.DataBindXY(lstDates.ToArray, lstValues.ToArray)
        lblUnitSales.Text = intTotalUnitsSold
        lblRetailValue.Text = Format(intTotalUnitsSold * prdCurrent.RetailPrice, "0.00")

    End Sub

#End Region

#Region "Form Events"


    Private Sub frmProductSales_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.Text = prdCurrent.Name
        lstMonths = New List(Of String)
        For i As Integer = 0 To 3
            lstMonths.Add(MonthName(dteEndDate.AddMonths(-3 + i).Month) & ", " & Year(Now.AddMonths(-3 + i)))
            mscUnitSales.Series(0).Points.AddXY(lstMonths(i), prdCurrent.UnitSales(i)) 'Adding points to mini Graph
        Next
        Try 'Needs to call database so use try catch
            SetGraph()
        Catch ex As OleDb.OleDbException 'Only need to catch database exceptions. All other exceptions should be caught in development
            MsgBox("There was an error retrieving sales data for " & prdCurrent.Name & ". Please try again. If the problem persists, please inform your System Administrator.")
            Me.Close()
        End Try

    End Sub

    Private Sub btnCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopy.Click

        CopyToClipboard(mscDailySales) 'Call graph function

    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        Try 'Savegraph routine use System.IO so might throw exception
            If SaveGraph(mscDailySales) Then
                MsgBox("Graph successfully saved.")
            End If
        Catch ex As System.IO.IOException 'Only need to catch IO exceptions. All other exceptions should be caught in development
            MsgBox("There was an error saving the Graph. Please try again. If the problem persists, please inform your System Administrator.")
        End Try

    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click

        Me.Close()

    End Sub

    Private Sub btnPrintPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPreview.Click

        PreviewGraph(mscDailySales) 'Call graph function

    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click

        Try 'Printgraph routine might throw printing exception
            PrintGraph(mscDailySales)
        Catch ex As System.Drawing.Printing.InvalidPrinterException 'Only need to catch Printing exceptions. All other exceptions should be caught in development
            MsgBox("There was an error printing the Report. Please try again. If the problem persists, please inform your System Administrator.")
        End Try

    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click 'Set graph back to square one

        dteStartDate = #11/1/2009#
        dteEndDate = #2/19/2010#
        SetGraph()
        btnReset.Visible = False

    End Sub

#Region "Graph Events"

    Private Sub mscUnitSales_GetToolTipText(ByVal sender As Object, ByVal e As System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs) Handles mscUnitSales.GetToolTipText

        Select Case e.HitTestResult.ChartElementType
            Case ChartElementType.DataPoint
                If e.HitTestResult.PointIndex >= 0 Then
                    e.Text = "Click to Zoom in on " & lstMonths(e.HitTestResult.PointIndex)
                End If
        End Select

    End Sub

    Private Sub mscUnitSales_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles mscUnitSales.MouseDown

        Dim htrResult As HitTestResult = mscUnitSales.HitTest(e.X, e.Y)
        If htrResult.ChartElementType = ChartElementType.DataPoint And htrResult.PointIndex >= 0 Then 'Check if mouse is over Data Point or Legend Item
            Select Case htrResult.PointIndex 'Each point represents one month sales
                Case 0
                    dteStartDate = #11/1/2009# 'Set Dates
                    dteEndDate = #11/30/2009#
                Case 1
                    dteStartDate = #12/1/2009#
                    dteEndDate = #12/31/2009#
                Case 2
                    dteStartDate = #1/1/2010#
                    dteEndDate = #1/31/2010#
                Case Else
                    dteStartDate = #2/1/2010#
                    dteEndDate = #2/19/2010#
            End Select
            SetGraph() 'Set Up Graph
            btnReset.Visible = True 'Make sure there is a way to return to full graph
        End If

    End Sub

    Private Sub mscUnitSales_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles mscUnitSales.MouseMove

        Dim htrResult As HitTestResult = mscUnitSales.HitTest(e.X, e.Y)
        For Each dp As DataPoint In mscUnitSales.Series(0).Points  'Go through points setting design elements back to default
            dp.BackSecondaryColor = Color.White
            dp.BackHatchStyle = ChartHatchStyle.None
            dp.BorderWidth = 0
        Next dp
        'If users mouse hovers over a datapoint or it's equivalent Legend Item then set cursor to hand to indicate that it is a link
        'Also we use some design elements to indicate which DataPoint is active
        If htrResult.PointIndex >= 0 Then
            If htrResult.ChartElementType = ChartElementType.DataPoint Or htrResult.ChartElementType = ChartElementType.LegendItem Then
                Me.Cursor = Cursors.Hand
                Dim dpSelected As DataPoint
                dpSelected = mscUnitSales.Series(0).Points(htrResult.PointIndex)
                dpSelected.BackSecondaryColor = Color.Olive
                dpSelected.BorderColor = Color.White
                dpSelected.BorderWidth = 1
            End If
        Else
            'Set cursor back to default when leaving selected datapoint
            Me.Cursor = Cursors.Default
        End If

    End Sub

#End Region

#End Region

End Class
