﻿Public Class frmSplash

    Private Main As frmChartExample

    Private Sub timSplash_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles timSplash.Tick

        Main.Visible = True
        Me.Close()

    End Sub

    Private Sub frmSplash_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Main = New frmChartExample
        Main.Visible = False
        timSplash.Start()

    End Sub

End Class