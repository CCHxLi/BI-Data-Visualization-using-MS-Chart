﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmChartExample
    Inherits Form
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series
        Dim DataPoint1 As System.Windows.Forms.DataVisualization.Charting.DataPoint = New System.Windows.Forms.DataVisualization.Charting.DataPoint(0, 45)
        Dim DataPoint2 As System.Windows.Forms.DataVisualization.Charting.DataPoint = New System.Windows.Forms.DataVisualization.Charting.DataPoint(1, 20)
        Dim DataPoint3 As System.Windows.Forms.DataVisualization.Charting.DataPoint = New System.Windows.Forms.DataVisualization.Charting.DataPoint(2, 20)
        Dim DataPoint4 As System.Windows.Forms.DataVisualization.Charting.DataPoint = New System.Windows.Forms.DataVisualization.Charting.DataPoint(3, 10)
        Dim DataPoint5 As System.Windows.Forms.DataVisualization.Charting.DataPoint = New System.Windows.Forms.DataVisualization.Charting.DataPoint(4, 5)
        Dim Title1 As System.Windows.Forms.DataVisualization.Charting.Title = New System.Windows.Forms.DataVisualization.Charting.Title
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmChartExample))
        Me.mscSales = New System.Windows.Forms.DataVisualization.Charting.Chart
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rbtnUnitSales = New System.Windows.Forms.RadioButton
        Me.rbtnGross = New System.Windows.Forms.RadioButton
        Me.rbtnPercent = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.rbtnMonth4 = New System.Windows.Forms.RadioButton
        Me.rbtnMonth3 = New System.Windows.Forms.RadioButton
        Me.rbtnMonth2 = New System.Windows.Forms.RadioButton
        Me.rbtnMonth1 = New System.Windows.Forms.RadioButton
        Me.dgvDetails = New System.Windows.Forms.DataGridView
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.lblPercentageValue = New System.Windows.Forms.Label
        Me.lbl20 = New System.Windows.Forms.Label
        Me.lbl0 = New System.Windows.Forms.Label
        Me.tbGroupPercentage = New System.Windows.Forms.TrackBar
        Me.pnlGroupPercentage = New System.Windows.Forms.Panel
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnCopy = New System.Windows.Forms.Button
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnPreview = New System.Windows.Forms.Button
        Me.btnPrint = New System.Windows.Forms.Button
        Me.btnQuit = New System.Windows.Forms.Button
        Me.btnReturn = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        CType(Me.mscSales, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgvDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tbGroupPercentage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlGroupPercentage.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'mscSales
        '
        Me.mscSales.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.mscSales.BackColor = System.Drawing.Color.Gray
        Me.mscSales.BackSecondaryColor = System.Drawing.Color.Silver
        Me.mscSales.BorderlineColor = System.Drawing.Color.Transparent
        Me.mscSales.BorderlineWidth = 3
        Me.mscSales.BorderSkin.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.mscSales.BorderSkin.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.VerticalCenter
        Me.mscSales.BorderSkin.BackSecondaryColor = System.Drawing.Color.White
        Me.mscSales.BorderSkin.BorderColor = System.Drawing.Color.Transparent
        Me.mscSales.BorderSkin.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        Me.mscSales.BorderSkin.BorderWidth = 2
        Me.mscSales.BorderSkin.PageColor = System.Drawing.Color.Transparent
        Me.mscSales.BorderSkin.SkinStyle = System.Windows.Forms.DataVisualization.Charting.BorderSkinStyle.FrameTitle1
        ChartArea1.Area3DStyle.Enable3D = True
        ChartArea1.Area3DStyle.Inclination = 45
        ChartArea1.Area3DStyle.IsClustered = True
        ChartArea1.Area3DStyle.IsRightAngleAxes = False
        ChartArea1.Area3DStyle.LightStyle = System.Windows.Forms.DataVisualization.Charting.LightStyle.Realistic
        ChartArea1.Area3DStyle.Perspective = 45
        ChartArea1.Area3DStyle.PointDepth = 60
        ChartArea1.Area3DStyle.PointGapDepth = 60
        ChartArea1.Area3DStyle.Rotation = 180
        ChartArea1.Area3DStyle.WallWidth = 30
        ChartArea1.BackColor = System.Drawing.Color.Transparent
        ChartArea1.BorderColor = System.Drawing.Color.Transparent
        ChartArea1.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid
        ChartArea1.BorderWidth = 0
        ChartArea1.Name = "ChartArea1"
        Me.mscSales.ChartAreas.Add(ChartArea1)
        Legend1.BackColor = System.Drawing.Color.Transparent
        Legend1.ForeColor = System.Drawing.Color.White
        Legend1.IsEquallySpacedItems = True
        Legend1.Name = "Legend1"
        Legend1.TitleAlignment = System.Drawing.StringAlignment.Far
        Legend1.TitleForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Legend1.TitleSeparatorColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.mscSales.Legends.Add(Legend1)
        Me.mscSales.Location = New System.Drawing.Point(256, 0)
        Me.mscSales.Name = "mscSales"
        Me.mscSales.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.None
        Me.mscSales.PaletteCustomColors = New System.Drawing.Color() {System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer)), System.Drawing.Color.Navy, System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer)), System.Drawing.Color.Blue, System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer)), System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))}
        Series1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.HorizontalCenter
        Series1.BackSecondaryColor = System.Drawing.Color.White
        Series1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Series1.BorderWidth = 0
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pyramid
        Series1.Color = System.Drawing.Color.White
        Series1.CustomProperties = "PieStartAngle=90, Pyramid3DDrawingStyle=CircularBase, PieDrawingStyle=Concave, Ca" & _
            "lloutLineColor=White, PyramidPointGap=1.5"
        Series1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Series1.IsValueShownAsLabel = True
        Series1.LabelBackColor = System.Drawing.Color.Transparent
        Series1.LabelBorderColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Series1.LabelBorderWidth = 0
        Series1.LabelForeColor = System.Drawing.Color.White
        Series1.Legend = "Legend1"
        Series1.MarkerBorderColor = System.Drawing.Color.Transparent
        Series1.Name = "GDS"
        DataPoint1.AxisLabel = "Filters"
        DataPoint1.LabelBackColor = System.Drawing.Color.Transparent
        DataPoint1.LabelBorderColor = System.Drawing.Color.White
        DataPoint2.AxisLabel = "Global Lubricants"
        DataPoint2.LabelBackColor = System.Drawing.Color.Transparent
        DataPoint2.LabelBorderColor = System.Drawing.Color.White
        DataPoint3.AxisLabel = "Castrol Lubricants"
        DataPoint3.LabelBackColor = System.Drawing.Color.Transparent
        DataPoint3.LabelBorderColor = System.Drawing.Color.White
        DataPoint4.AxisLabel = "Three Way Distributors "
        DataPoint4.LabelBackColor = System.Drawing.Color.Transparent
        DataPoint4.LabelBorderColor = System.Drawing.Color.White
        DataPoint5.AxisLabel = "Additives"
        DataPoint5.LabelBackColor = System.Drawing.Color.Transparent
        DataPoint5.LabelBorderColor = System.Drawing.Color.White
        Series1.Points.Add(DataPoint1)
        Series1.Points.Add(DataPoint2)
        Series1.Points.Add(DataPoint3)
        Series1.Points.Add(DataPoint4)
        Series1.Points.Add(DataPoint5)
        Series1.SmartLabelStyle.AllowOutsidePlotArea = System.Windows.Forms.DataVisualization.Charting.LabelOutsidePlotAreaStyle.Yes
        Me.mscSales.Series.Add(Series1)
        Me.mscSales.Size = New System.Drawing.Size(513, 544)
        Me.mscSales.TabIndex = 17
        Me.mscSales.Text = "Sales"
        Title1.Alignment = System.Drawing.ContentAlignment.TopCenter
        Title1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World, CType(0, Byte), True)
        Title1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Title1.Name = "Title1"
        Title1.ShadowOffset = 2
        Title1.Text = "SALES BY CATEGORY - PERCENT OF GROSS SALES"
        Title1.TextStyle = System.Windows.Forms.DataVisualization.Charting.TextStyle.Embed
        Me.mscSales.Titles.Add(Title1)
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbtnUnitSales)
        Me.GroupBox2.Controls.Add(Me.rbtnGross)
        Me.GroupBox2.Controls.Add(Me.rbtnPercent)
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox2.Location = New System.Drawing.Point(12, 151)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(227, 97)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Chart Sales as :"
        '
        'rbtnUnitSales
        '
        Me.rbtnUnitSales.AutoSize = True
        Me.rbtnUnitSales.Location = New System.Drawing.Point(14, 65)
        Me.rbtnUnitSales.Name = "rbtnUnitSales"
        Me.rbtnUnitSales.Size = New System.Drawing.Size(73, 17)
        Me.rbtnUnitSales.TabIndex = 2
        Me.rbtnUnitSales.Text = "Unit Sales"
        Me.rbtnUnitSales.UseVisualStyleBackColor = True
        Me.rbtnUnitSales.Visible = False
        '
        'rbtnGross
        '
        Me.rbtnGross.AutoSize = True
        Me.rbtnGross.Location = New System.Drawing.Point(14, 42)
        Me.rbtnGross.Name = "rbtnGross"
        Me.rbtnGross.Size = New System.Drawing.Size(82, 17)
        Me.rbtnGross.TabIndex = 1
        Me.rbtnGross.Text = "Retail Value"
        Me.rbtnGross.UseVisualStyleBackColor = True
        '
        'rbtnPercent
        '
        Me.rbtnPercent.AutoSize = True
        Me.rbtnPercent.Location = New System.Drawing.Point(14, 19)
        Me.rbtnPercent.Name = "rbtnPercent"
        Me.rbtnPercent.Size = New System.Drawing.Size(133, 17)
        Me.rbtnPercent.TabIndex = 0
        Me.rbtnPercent.Text = "Percent of Gross Sales"
        Me.rbtnPercent.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbtnMonth4)
        Me.GroupBox1.Controls.Add(Me.rbtnMonth3)
        Me.GroupBox1.Controls.Add(Me.rbtnMonth2)
        Me.GroupBox1.Controls.Add(Me.rbtnMonth1)
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(227, 133)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Month"
        '
        'rbtnMonth4
        '
        Me.rbtnMonth4.AutoSize = True
        Me.rbtnMonth4.Location = New System.Drawing.Point(14, 98)
        Me.rbtnMonth4.Name = "rbtnMonth4"
        Me.rbtnMonth4.Size = New System.Drawing.Size(92, 17)
        Me.rbtnMonth4.TabIndex = 3
        Me.rbtnMonth4.Tag = "3"
        Me.rbtnMonth4.Text = "Current Month"
        Me.rbtnMonth4.UseVisualStyleBackColor = True
        '
        'rbtnMonth3
        '
        Me.rbtnMonth3.AutoSize = True
        Me.rbtnMonth3.Location = New System.Drawing.Point(14, 75)
        Me.rbtnMonth3.Name = "rbtnMonth3"
        Me.rbtnMonth3.Size = New System.Drawing.Size(61, 17)
        Me.rbtnMonth3.TabIndex = 2
        Me.rbtnMonth3.Tag = "2"
        Me.rbtnMonth3.Text = "Month3"
        Me.rbtnMonth3.UseVisualStyleBackColor = True
        '
        'rbtnMonth2
        '
        Me.rbtnMonth2.AutoSize = True
        Me.rbtnMonth2.Location = New System.Drawing.Point(14, 52)
        Me.rbtnMonth2.Name = "rbtnMonth2"
        Me.rbtnMonth2.Size = New System.Drawing.Size(61, 17)
        Me.rbtnMonth2.TabIndex = 1
        Me.rbtnMonth2.Tag = "1"
        Me.rbtnMonth2.Text = "Month2"
        Me.rbtnMonth2.UseVisualStyleBackColor = True
        '
        'rbtnMonth1
        '
        Me.rbtnMonth1.AutoSize = True
        Me.rbtnMonth1.Location = New System.Drawing.Point(14, 29)
        Me.rbtnMonth1.Name = "rbtnMonth1"
        Me.rbtnMonth1.Size = New System.Drawing.Size(61, 17)
        Me.rbtnMonth1.TabIndex = 0
        Me.rbtnMonth1.Tag = "0"
        Me.rbtnMonth1.Text = "Month1"
        Me.rbtnMonth1.UseVisualStyleBackColor = True
        '
        'dgvDetails
        '
        Me.dgvDetails.BackgroundColor = System.Drawing.Color.White
        Me.dgvDetails.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvDetails.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvDetails.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDetails.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvDetails.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgvDetails.EnableHeadersVisualStyles = False
        Me.dgvDetails.GridColor = System.Drawing.Color.White
        Me.dgvDetails.Location = New System.Drawing.Point(12, 254)
        Me.dgvDetails.Name = "dgvDetails"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvDetails.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvDetails.RowHeadersVisible = False
        Me.dgvDetails.Size = New System.Drawing.Size(227, 278)
        Me.dgvDetails.TabIndex = 23
        '
        'Column1
        '
        Me.Column1.HeaderText = "Category"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 135
        '
        'Column2
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column2.DefaultCellStyle = DataGridViewCellStyle2
        Me.Column2.HeaderText = "Sales"
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 70
        '
        'lblPercentageValue
        '
        Me.lblPercentageValue.AutoSize = True
        Me.lblPercentageValue.BackColor = System.Drawing.Color.Gray
        Me.lblPercentageValue.ForeColor = System.Drawing.Color.White
        Me.lblPercentageValue.Location = New System.Drawing.Point(-1, 53)
        Me.lblPercentageValue.Name = "lblPercentageValue"
        Me.lblPercentageValue.Size = New System.Drawing.Size(312, 13)
        Me.lblPercentageValue.TabIndex = 33
        Me.lblPercentageValue.Text = "GROUPING PRODUCTS  HAVING LESS THAN 3 % OF SALES"
        '
        'lbl20
        '
        Me.lbl20.AutoSize = True
        Me.lbl20.BackColor = System.Drawing.Color.Gray
        Me.lbl20.ForeColor = System.Drawing.Color.White
        Me.lbl20.Location = New System.Drawing.Point(272, 1)
        Me.lbl20.Name = "lbl20"
        Me.lbl20.Size = New System.Drawing.Size(19, 13)
        Me.lbl20.TabIndex = 32
        Me.lbl20.Text = "20"
        '
        'lbl0
        '
        Me.lbl0.AutoSize = True
        Me.lbl0.BackColor = System.Drawing.Color.Gray
        Me.lbl0.ForeColor = System.Drawing.Color.White
        Me.lbl0.Location = New System.Drawing.Point(22, 1)
        Me.lbl0.Name = "lbl0"
        Me.lbl0.Size = New System.Drawing.Size(13, 13)
        Me.lbl0.TabIndex = 31
        Me.lbl0.Text = "0"
        '
        'tbGroupPercentage
        '
        Me.tbGroupPercentage.AutoSize = False
        Me.tbGroupPercentage.BackColor = System.Drawing.Color.Gray
        Me.tbGroupPercentage.Location = New System.Drawing.Point(14, 17)
        Me.tbGroupPercentage.Maximum = 20
        Me.tbGroupPercentage.Name = "tbGroupPercentage"
        Me.tbGroupPercentage.Size = New System.Drawing.Size(281, 30)
        Me.tbGroupPercentage.TabIndex = 0
        Me.tbGroupPercentage.TickStyle = System.Windows.Forms.TickStyle.TopLeft
        '
        'pnlGroupPercentage
        '
        Me.pnlGroupPercentage.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.pnlGroupPercentage.BackColor = System.Drawing.Color.Gray
        Me.pnlGroupPercentage.Controls.Add(Me.tbGroupPercentage)
        Me.pnlGroupPercentage.Controls.Add(Me.lblPercentageValue)
        Me.pnlGroupPercentage.Controls.Add(Me.lbl0)
        Me.pnlGroupPercentage.Controls.Add(Me.lbl20)
        Me.pnlGroupPercentage.Location = New System.Drawing.Point(286, 448)
        Me.pnlGroupPercentage.Name = "pnlGroupPercentage"
        Me.pnlGroupPercentage.Size = New System.Drawing.Size(314, 67)
        Me.pnlGroupPercentage.TabIndex = 34
        '
        'btnCopy
        '
        Me.btnCopy.BackgroundImage = CType(resources.GetObject("btnCopy.BackgroundImage"), System.Drawing.Image)
        Me.btnCopy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnCopy.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnCopy.Location = New System.Drawing.Point(3, 16)
        Me.btnCopy.Name = "btnCopy"
        Me.btnCopy.Size = New System.Drawing.Size(42, 42)
        Me.btnCopy.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.btnCopy, "Copy")
        Me.btnCopy.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.BackgroundImage = CType(resources.GetObject("btnSave.BackgroundImage"), System.Drawing.Image)
        Me.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnSave.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnSave.Location = New System.Drawing.Point(3, 58)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(42, 42)
        Me.btnSave.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.btnSave, "Save Graph as Image")
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnPreview
        '
        Me.btnPreview.BackgroundImage = CType(resources.GetObject("btnPreview.BackgroundImage"), System.Drawing.Image)
        Me.btnPreview.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnPreview.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnPreview.Location = New System.Drawing.Point(3, 100)
        Me.btnPreview.Name = "btnPreview"
        Me.btnPreview.Size = New System.Drawing.Size(42, 42)
        Me.btnPreview.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.btnPreview, "Print Preview")
        Me.btnPreview.UseVisualStyleBackColor = True
        '
        'btnPrint
        '
        Me.btnPrint.BackgroundImage = CType(resources.GetObject("btnPrint.BackgroundImage"), System.Drawing.Image)
        Me.btnPrint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnPrint.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnPrint.Location = New System.Drawing.Point(3, 142)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(42, 42)
        Me.btnPrint.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.btnPrint, "Print")
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'btnQuit
        '
        Me.btnQuit.BackgroundImage = CType(resources.GetObject("btnQuit.BackgroundImage"), System.Drawing.Image)
        Me.btnQuit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnQuit.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnQuit.Location = New System.Drawing.Point(3, 499)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(42, 42)
        Me.btnQuit.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.btnQuit, "Quit Application")
        Me.btnQuit.UseVisualStyleBackColor = True
        '
        'btnReturn
        '
        Me.btnReturn.BackgroundImage = CType(resources.GetObject("btnReturn.BackgroundImage"), System.Drawing.Image)
        Me.btnReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnReturn.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnReturn.Location = New System.Drawing.Point(3, 457)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(42, 42)
        Me.btnReturn.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.btnReturn, "Return to Category View")
        Me.btnReturn.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnReturn)
        Me.GroupBox3.Controls.Add(Me.btnQuit)
        Me.GroupBox3.Controls.Add(Me.btnPrint)
        Me.GroupBox3.Controls.Add(Me.btnPreview)
        Me.GroupBox3.Controls.Add(Me.btnSave)
        Me.GroupBox3.Controls.Add(Me.btnCopy)
        Me.GroupBox3.Dock = System.Windows.Forms.DockStyle.Right
        Me.GroupBox3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox3.Location = New System.Drawing.Point(769, 0)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(48, 544)
        Me.GroupBox3.TabIndex = 35
        Me.GroupBox3.TabStop = False
        '
        'frmChartExample
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(817, 544)
        Me.Controls.Add(Me.pnlGroupPercentage)
        Me.Controls.Add(Me.mscSales)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.dgvDetails)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmChartExample"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MS Chart Example"
        CType(Me.mscSales, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dgvDetails, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tbGroupPercentage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlGroupPercentage.ResumeLayout(False)
        Me.pnlGroupPercentage.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents mscSales As System.Windows.Forms.DataVisualization.Charting.Chart
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbtnGross As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnPercent As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbtnMonth4 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnMonth3 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnMonth2 As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnMonth1 As System.Windows.Forms.RadioButton
    Friend WithEvents dgvDetails As System.Windows.Forms.DataGridView
    Friend WithEvents rbtnUnitSales As System.Windows.Forms.RadioButton
    Friend WithEvents lblPercentageValue As System.Windows.Forms.Label
    Friend WithEvents lbl20 As System.Windows.Forms.Label
    Friend WithEvents lbl0 As System.Windows.Forms.Label
    Friend WithEvents tbGroupPercentage As System.Windows.Forms.TrackBar
    Friend WithEvents pnlGroupPercentage As System.Windows.Forms.Panel
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnCopy As System.Windows.Forms.Button
    Friend WithEvents btnReturn As System.Windows.Forms.Button
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents btnPreview As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
